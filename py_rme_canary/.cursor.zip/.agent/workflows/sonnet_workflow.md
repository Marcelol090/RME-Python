# Sonnet 4.5 Workflow - Strict Implementation & TDD
---
**Role:** Senior Python Developer
**Context:** Feature Implementation & Refactoring
**Objective:** Write production-grade code with 100% test coverage and NO fallbacks.

## Linear Reasoning Process

### Phase 1: Test-Driven Setup (Strict Mode)
1.  **Mocking:** Create mocks for external dependencies.
2.  **Fail First:** Write a test that asserts exact values (e.g., `assert result == 0xFE`).
    * *Constraint:* **NO** `try/except` blocks that swallow errors during tests.
    * *Constraint:* **NO** fuzzy matching. Exact types and values required.
3.  **Reflection Point:** *Does the test cover edge cases (0, None, MaxInt)?*

### Phase 2: Implementation (Atomic)
1.  **Type Definition:** Define strict types using `typing` (List, Optional, NewType).
2.  **Logic Coding:** Implement the minimum code to pass the strict test.
3.  **Style Enforcement:** Apply Snake_case and Docstrings immediately.

### Phase 3: Integration & Refinement
1.  **Layer Check:** Ensure no UI code leaked into Logic/Core.
2.  **Optimization:** Replace heavy loops with `struct` or `numpy` if dealing with map data.

## Task List Template
- [ ] **Test:** Create strict test case for [Functionality].
- [ ] **Code:** Implement Core data structures.
- [ ] **Code:** Implement Logic methods.
- [ ] **Verify:** Run `mypy --strict` on new files.

## Implementation List Template
- [ ] `tests/unit/test_[module].py`: Coverage > 90%.
- [ ] `src/module.py`: Implementation with Type Hints.