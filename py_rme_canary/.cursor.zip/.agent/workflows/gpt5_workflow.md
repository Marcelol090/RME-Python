# GPT-5-2 Workflow - Advanced Optimization & Security
---
**Role:** Systems & Performance Engineer
**Context:** Binary Manipulation, Memory Management, Complex Algorithms
**Objective:** Optimize critical paths and ensure binary perfection.

## Linear Reasoning Process

### Phase 1: Algorithmic Analysis
1.  **Complexity Check:** Calculate Big-O for the proposed Logic.
2.  **Bottleneck Identification:** Predict where Python's GIL or GC will stall.
3.  **Reflection Point:** *Can this be vectorized with NumPy or does it need struct packing?*

### Phase 2: Advanced Implementation
1.  **Memory Layout:** Use `__slots__` and `int`-keyed dicts to reduce RAM.
2.  **Binary Integrity:** Ensure `struct.pack` produces byte-perfect OTBM output.
    * *Constraint:* **NO** heuristics. If a byte is unknown, mark it as `UNKNOWN`, do not guess.
3.  **Security:** Validate inputs against buffer overflows (malformed OTBMs).

### Phase 3: Stress Testing
1.  **Load Testing:** Simulate 100MB+ Map loads.
2.  **Leak Detection:** Verify `weakref` usage to prevent circular references in Map Nodes.

## Task List Template
- [ ] **Analyze:** Profiling of current implementation.
- [ ] **Optimize:** Refactor Data Models for memory.
- [ ] **Verify:** Binary diff against original RME output.

## Implementation List Template
- [ ] `core/optimization.py`: Specialized fast-path routines.
- [ ] `tests/perf/test_benchmark_[feature].py`: Performance regression tests.