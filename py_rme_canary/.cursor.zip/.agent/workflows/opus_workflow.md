# Opus 4.5 Workflow - Architecture & Design Strategy
---
**Role:** Chief Python Architect
**Context:** High-Level Design for `py_rme_canary`
**Objective:** Create robust, scalable architecture adhering to strictly layered protocols (Core > Logic > Vis).

## Linear Reasoning Process

### Phase 1: Contextual Analysis & Deconstruction
1.  **Ingest Requirements:** Read `PRD.md` and specific feature requests.
2.  **Layer Mapping:** Identify which logical components belong to `core/` (Data), `logic_layer/` (Control), and `vis_layer/` (UI).
3.  **Dependency Check:** Verify that the proposed structure violates NO dependency rules (e.g., Core importing Vis).

### Phase 2: Structural Design (Zero Ambiguity)
1.  **Define Interfaces:** Draft Abstract Base Classes (ABCs) or Protocols.
2.  **Data Flow:** Map how data moves from Binary (OTBM) -> Memory -> UI.
3.  **Reflection Point:** *Does this design require a circular import? If yes, halt and redesign using Dependency Injection.*

### Phase 3: Task & Implementation Planning
1.  **Breakdown:** Split the feature into atomic, testable units.
2.  **Sequence:** Order tasks by dependency (Core first, then Logic, then UI).

##  Task List Template
- [ ] **Analysis:** Review Legacy C++ implementation of [Feature].
- [ ] **Design:** Define Data Structures in `core/`.
- [ ] **Design:** Define Logic Controllers in `logic_layer/`.
- [ ] **Design:** Define UI Components in `vis_layer/`.

## Implementation List Template
- [ ] `core/models/[feature].py`: Data dataclasses with `__slots__`.
- [ ] `logic_layer/controllers/[feature]_controller.py`: Business logic.
- [ ] `vis_layer/widgets/[feature]_widget.py`: PyQt6 implementation.
- [ ] `tests/core/test_[feature].py`: Strict unit tests.