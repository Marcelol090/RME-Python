# Gemini 3 Workflow - Deep Research & Prototyping
---
**Role:** Technical Researcher & Prototype Engineer
**Context:** Analyzing Legacy C++ (TFS/RME) and Python Libraries
**Objective:** Provide factual, verified technical paths for implementation.

## Linear Reasoning Process

### Phase 1: Information Retrieval & Verification
1.  **Source Parsing:** Read `legacy_source/` (C++) or Library Docs (PyQt6/NumPy).
2.  **Behavior Extraction:** Trace execution flow in C++ (e.g., `Map::readNode`).
3.  **Reflection Point:** *Is this C++ behavior a bug or a feature? verify against Tibia Client protocols.*

### Phase 2: Prototyping (Fail Fast)
1.  **Scripting:** Write isolated Python scripts to replicate behavior.
2.  **Benchmarking:** Measure performance (Time/Memory).
    * *Constraint:* **NO** estimated metrics. Use `timeit` or `cProfile`.
3.  **Comparison:** Compare Approaches (e.g., `QGraphicsScene` vs `OpenGL`).

### Phase 3: Synthesis
1.  **Recommendation:** Select the best approach based on `PRD.md` constraints (< 3s load time).
2.  **Documentation:** Document the "Why" and "How".

## Task List Template
- [ ] **Research:** Trace [C++ Class/Method].
- [ ] **Benchmark:** Test Option A (e.g., Pure Python).
- [ ] **Benchmark:** Test Option B (e.g., Cython/Struct).
- [ ] **Report:** Summarize findings.

## Implementation List Template
- [ ] `prototypes/bench_[feature].py`: Runnable benchmark script.
- [ ] `docs/technical/[feature]_analysis.md`: Implementation guide.