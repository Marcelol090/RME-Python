# Common Project Rules

## 1. Zero Fallback Policy
- **Tests:** Assertions must be absolute. `assert x == 5`, never `assert x > 0` (unless logic dictates range).
- **Parsing:** If binary data is malformed, raise `CorruptDataError`. Do not attempt to "repair" silently.
- **Typing:** No `Any`. Use explicit types.

## 2. Linear Reasoning
- Do not jump to coding. **Plan -> Verify -> Code -> Refactor**.
- Always check `PROJECT_STRUCTURE.md` before importing a module.

## 3. Layered Architecture (Strict)
- **Core:** Data only.
- **Logic:** Business Logic.
- **Vis:** PyQt6 UI.
- *Violation:* Importing `PyQt6` in `Core` triggers an immediate halt.