# Common Project Rules

## 1. Zero Fallback Policy
- **Tests:** Assertions must be absolute. `assert x == 5`, never `assert x > 0` (unless logic dictates range).
- **Parsing:** If binary data is malformed, raise `CorruptDataError`. Do not attempt to "repair" silently.
- **Typing:** No `Any`. Use explicit types.

## 2. Linear Reasoning
- Do not jump to coding. **Plan -> Verify -> Code -> Refactor**.
- Always check `PROJECT_STRUCTURE.md` before importing a module.

## 3. Layered Architecture (Strict)
- **Core:** Data only.
- **Logic:** Business Logic.
- **Vis:** PyQt6 UI.
- *Violation:* Importing `PyQt6` in `Core` triggers an immediate halt.

---
description: STRICT Project Structure & Layering Rules
globs: py_rme_canary/**/*.py
---
# Project Structure Enforcement (PROJECT_STRUCTURE.md)

## Layer Boundaries (CRITICAL)
1.  **core/**:
    * CANNOT IMPORT: `vis_layer`, `logic_layer`, `PyQt6`
    * CAN IMPORT: `struct`, `pathlib`, `numpy`
2.  **logic_layer/**:
    * CANNOT IMPORT: `vis_layer`, `PyQt6` (except for signals/slots definitions)
    * CAN IMPORT: `core`
3.  **vis_layer/**:
    * CAN IMPORT: `core`, `logic_layer`, `PyQt6`

## File Naming
- Modules: `lowercase_with_underscores.py`
- Classes: `PascalCase`
- Tests: `test_modulename.py` in `tests/` folder matching source structure.

## Forbidden Patterns
- `from module import *` (Wildcard imports)
- Circular dependencies (use `TYPE_CHECKING` block for type hints).